﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
     class Takim
    {
        Asker[] birlik = new Asker[7];
        Random r = new Random();
        public Asker[] Birlik { get { return birlik; } set { birlik = value; } }
        public string name;
        public Takim(int koord_x,int koord_y,Ermeydani m,string isim)
        {
            name = isim;
            for (int i = 0; i < birlik.Length; i++)
            {
                if (i == 0) birlik[i] = new Yuzbasi(koord_x,koord_y,m);
                else if (i == 1 || i == 2)
                {
                    birlik[i] = new Tegmen(koord_x, koord_y, m);//koordinat implementasyonunu unutma!!
                }
                else
                {
                    birlik[i] = new Er(koord_x, koord_y, m);//koordinat implementasyonunu unutma!!
                }
            }
        }

        public Asker AskerSec(Takim t)
        {
            int rastgeleSec = r.Next(t.Birlik.Length);
            while(!t.Birlik[rastgeleSec].HayattaMi)
            {
                rastgeleSec = r.Next(t.Birlik.Length);
            }

            return t.Birlik[rastgeleSec];
        }
        // ..... //
    }
}
