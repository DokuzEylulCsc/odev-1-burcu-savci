﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Program
    {


        static Ermeydani meydan;
        static Takim t1;
        static Takim t2;
        static bool siraHangiTakimda;
        static void Main(string[] args)
        {
            /*
             Örnek olması açısında iskelet kod hazır olarak verilmiştir. İmplementasyonunuz bunun üzerinden gerçekleştiriniz.
            */
            meydan = new Ermeydani();
            t1 = new Takim(0, 5,meydan,"A");
            t2 = new Takim(11,16,meydan,"B");
            siraHangiTakimda = false;//Default olarak t1 takımından başlayacak şekilde ayarlandı.
            
            SavasiBaslat();
            



            //TAKIM BİLGİLERİNİ YAZDIRMADA KULLANILABİLİR
            //for (int i = 0; i < meydan.Harita.GetLength(0); i++)
            //{
            //    for (int j = 0; j < meydan.Harita.GetLength(1); j++)
            //    {
            //        if(meydan.Harita[i,j].Asker!=null)
            //        {
            //            Console.WriteLine("{0}\t{1},{2}",meydan.Harita[i, j].Asker.GetType().Name,i,j);
            //        }
            //    }

            //}

        }

        static bool DevamMi()
        {
            bool control1 = false;
            bool control2 = false;

            for (int i = 0; i <t1.Birlik.Length ; i++)
            {
                if(t1.Birlik[i].HayattaMi)
                {
                    control1 = true;
                    break;
                }
            }

            for (int i = 0; i < t2.Birlik.Length; i++)
            {
                if (t2.Birlik[i].HayattaMi)
                {
                    control2 = true;
                    break;
                }
            }

            return control1 & control2;
        }

        static void SavasiBaslat()
        {
            Asker asker;
            while(DevamMi())
            {
                if(!siraHangiTakimda)
                {
                    //t1 takımından  hayatta olan bir asker seçilecek
                    asker=t1.AskerSec(t1);
                }
                else
                {
                    asker=t2.AskerSec(t2);
                }

                //Asker Belirlendi
                switch (HareketSec())
                {
                    case 1:asker.Bekle(); break;
                    case 2: asker.HaraketEt(asker,meydan); break;
                    case 3: asker.AtesEt(asker,meydan); break;
                        default:
                        {
                            Console.Clear();
                            Console.WriteLine("Program Çalışırken Bir Hata Oluştu!");
                            return;
                        }
                }

                siraHangiTakimda = !siraHangiTakimda;              

            }
            Console.WriteLine("Oyun Sona Erdi!");
        }

        static int HareketSec()
        {
            Random r = new Random();
            int sansDegiskeni=r.Next(10);
            if(sansDegiskeni==0)
            {
                return 1;//Bekle()
            }
            else if(sansDegiskeni>0 && sansDegiskeni<6)
            {
                return 2;//HareketEt()
            }
            else
            {
                return 3; //AtesEt()
            }
        }
    }
}
