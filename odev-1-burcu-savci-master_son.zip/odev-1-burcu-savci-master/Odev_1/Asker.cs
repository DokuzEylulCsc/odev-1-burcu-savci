﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    abstract class Asker
    {
        Random r = new Random();
        private Bolge koordinat;
        private bool hayattaMi;
        private string takimBilgisi;
        private int saglikBilgisi;

        public Bolge Koordinat { get { return koordinat; } }
        public bool HayattaMi { get => hayattaMi; set => hayattaMi = value; }
        public string TakimBilgisi { get => takimBilgisi; set => takimBilgisi = value; }
        public int SaglikBilgisi { get => saglikBilgisi; set => saglikBilgisi = value; }

        public Asker(int coord_x,int coord_y,Ermeydani m)
        {

            int x = r.Next(coord_x, coord_y);
            int y= r.Next(coord_x, coord_y);
            while (m.Harita[x, y].Asker != null)
            {
                x = r.Next(coord_x, coord_y);
                y = r.Next(coord_x, coord_y);
            }
            m.Harita[x, y].Asker = this;
            this.koordinat = new Bolge(x,y,this);
            saglikBilgisi=100;
        }
        // ..... //

        //Abstract sınıfların implementasyonları çoçuk sınıflarda gerçekleştirilmelidir.
        public abstract void HaraketEt(Asker a,Ermeydani m);

        public abstract void Bekle();

        public abstract void AtesEt(Asker a,Ermeydani m);
        // ..... //

    }
}
