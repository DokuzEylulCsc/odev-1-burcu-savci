﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Ermeydani
    {
        Bolge[,] harita = new Bolge[16, 16];

        public Bolge[,] Harita { get { return harita; } set { harita = value; } }
        public Ermeydani()
        {
            for (int i = 0; i < harita.GetLength(0); i++)
            {
                for (int j = 0; j < harita.GetLength(1); j++)
                {
                    harita[i, j] = new Bolge(i, j);
                }
            }
        }

        // ..... //
    }
}
