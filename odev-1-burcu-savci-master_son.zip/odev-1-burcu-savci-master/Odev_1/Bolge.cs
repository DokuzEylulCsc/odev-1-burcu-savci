﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Bolge
    {
        // ..... //

        int x, y;
        Asker asker;

        public int X { get => x; set => x = value; }
        public int Y { get => y; set => y = value; }
        internal Asker Asker { get => asker; set => asker = value; }


        public Bolge()
        {
            Asker = null;
        }

        public Bolge(int cx,int cy)
        {
            X = cx;
            Y = cy;
            asker = null;
        }

        public Bolge(int cx,int cy,Asker a)
        {
           X = cx;
           Y = cy;
           asker = a;
            
        }
       
    }
}
