﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Yuzbasi : Asker
    {
        // ..... //

        
        public Yuzbasi(int cx,int cy,Ermeydani m):base(cx,cy,m)
        {

        }

        public override void Bekle()
        {
            
        }

        public override void HaraketEt(Asker a, Ermeydani m)
        {
            List<Bolge> bosOlanBolgeler = new List<Bolge>();
            for (int i = a.Koordinat.X-1; i <= a.Koordinat.X+1; i++)
            {
                for (int j = a.Koordinat.Y-1; j <= a.Koordinat.Y+1; j++)
                {
                    if (i==a.Koordinat.X && j==a.Koordinat.Y) continue;
                    else
                    {
                        try
                        {
                            if(m.Harita[i,j].Asker==null)
                            {
                                bosOlanBolgeler.Add(m.Harita[i, j]);
                            }
                        }
                        catch (Exception)
                        {
                            //throwlu olan halini dene UNUTMA!
                        }
                    }
                }
            }

            //Boş olan bölge varsa birisi rastgele belirlenir ve ilgili asker ilgili konuma yerleştirilir.
            if(bosOlanBolgeler.Count>0)
            {
                Random r = new Random();
                int indis = r.Next(bosOlanBolgeler.Count - 1);
                Bolge b = bosOlanBolgeler[indis];
                m.Harita[b.X, b.Y].Asker = a;
                a.Koordinat.Asker = null;
                a.Koordinat.X = b.X;
                a.Koordinat.Y = b.Y;
            }



        }

        public override void AtesEt(Asker a, Ermeydani m)
        {
            List<Asker> menzilIcerisindeOlanlar = new List<Asker>();
            for (int i = a.Koordinat.X - 3; i <= a.Koordinat.X + 3; i++)
            {
                for (int j = a.Koordinat.Y - 3; j <= a.Koordinat.Y + 3; j++)
                {
                    if (i == a.Koordinat.X && j == a.Koordinat.Y) continue;
                    else
                    {
                        try
                        {
                            if (m.Harita[i, j].Asker != null && m.Harita[i,j].Asker.TakimBilgisi!=a.TakimBilgisi)
                            {
                                menzilIcerisindeOlanlar.Add(m.Harita[i, j].Asker);
                            }
                        }
                        catch (Exception)
                        {
                            //throwlu olan halini dene UNUTMA!
                        }
                    }
                }
            }

            Random r = new Random();
            int sansDegiskeni=r.Next(10);
            int swtch;
            if(sansDegiskeni>=4)
            {
                swtch = 40;
            }
            else if(sansDegiskeni>=1 && sansDegiskeni<4)
            {
                swtch = 25;
            }
            else
            {
                swtch = 15;
            }

            int olecekAsker = r.Next(menzilIcerisindeOlanlar.Count - 1);
            Asker askr = menzilIcerisindeOlanlar[olecekAsker];

            m.Harita[askr.Koordinat.X, askr.Koordinat.Y].Asker.SaglikBilgisi -= swtch;
            if (m.Harita[askr.Koordinat.X, askr.Koordinat.Y].Asker.SaglikBilgisi <= 0) m.Harita[askr.Koordinat.X, askr.Koordinat.Y].Asker.HayattaMi = false;


        }


    }
}
